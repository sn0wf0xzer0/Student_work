//Vigenere Cipher

#include <string>
#include <iostream>
using namespace std;

string encrypt(string msg, string key)
{
	string cyp;
	int j = 0;
	for(int i = 0; i < msg.length(); i++, j++){
		j %= key.length();
		int m = toupper(msg[i]) - 'A';
		int k = toupper(key[j]) - 'A';
		int c = (m + k) % 26;
		cyp += (c + 'A');
	}
	return cyp;
}

string decrypt(string cyp, string key)
{
	string msg;

	for(int i = 0,j = 0; i < msg.length(); i++, j++){
		j %= key.length();
		int m = toupper(msg[i]) - 'A';
		int k = toupper(key[j]) - 'A';
		int c = (m - k) % 26;
		if (c < 0)
			c += 26;
		msg += (c + 'A');
	}
	return msg;
}

int main()
{
	string msg, cyp, key;

	cout << "Enter a message: ";
	//cin >> msg;
	getline(cin, msg);
	cout << "Enter key: ";
	//cin >> key;
	getline(cin, key);
	cout << "Cypher: " << encrypt(msg, key) << endl;
}