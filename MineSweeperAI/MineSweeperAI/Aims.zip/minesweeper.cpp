//*Idea! divide the field into four sectors: 5X5, choose the middle most as a test clockwise, looking for a zero.

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Aims.h"
using namespace std;

const int BOMB = 9;
const int WIDTH  = 10;
const int HEIGHT = 10;

//initializes pure int field for AI consideration
//Without accidently peeking at which spaces are mines.
int **AI_field(int width, int height);

//count all bombs around location x,y
int CountAdjBombs(int field[][HEIGHT], int x, int y)
{
	int count = 0;
	for (int i=x-1; i<= x+1; i++)
	{
		for (int j=y-1; j<= y+1; j++)
		{
			if (i<0 || i>=WIDTH || j<0 || j>= HEIGHT)
				continue;
			if (field[i][j] == BOMB)
				count++;
		}
	}
	return count;

}


//1. place numbombs randomly
//2. count surrounding bombs
//3. negate, subtract 1 (flag as hidden)
void SetupMineField(int field[ ][HEIGHT], int numbombs)
{
	int x,y;
	for (int i=0; i<numbombs; i++)
	{
		x = rand()%WIDTH;
		y = rand()%HEIGHT;

		if (field[x][y] == BOMB)
			i--;
		else
			field[x][y] = BOMB;
	}

	//count nearby bombs
	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			if (field[x][y] == BOMB)
				continue;
			field[x][y] = CountAdjBombs(field, x, y);
		}
	}

	//hide field
	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			field[x][y] = -field[x][y] - 1;
		}
	}
}

//double for loop, 
// print 'X' if value is < 0, 'B' if bomb,
// print value otherwise
void DisplayField(int field[ ][HEIGHT], int **aiField)
{
	cout << "  0 1 2 3 4 5 6 7 8 9 x\n";
	for (int y=0; y<HEIGHT; y++)
	{
		cout << y << " ";
		for (int x=0; x<WIDTH; x++)
		{
			if (field[x][y] < 0){
				cout << 'X';
				aiField[x][y] = -1;
			}
			else if (field[x][y] == BOMB)
				cout << 'B';
			else{
				cout << field[x][y];
				aiField[x][y] = field[x][y];
			}
			cout << " ";

		}
		cout << endl;
	}
	cout << "y \n";
}


// add one, flip sign to x, y coord
// return true if BOMB, false otherwise
bool Reveal(int field[][HEIGHT], int x, int y)
{
	//return if out of bounds entry
	if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT)
		return false;
	
	//reveal
	if (field[x][y] < 0)
		field[x][y] = -(field[x][y] + 1);

	//return true if bomb
	if (field[x][y] == BOMB)
		return true;
	return false;
}

int main()
{
	srand(time(NULL));

	int minefield[WIDTH][HEIGHT] = {0};
	int **displayedfield;					//This is the AI's interpretation of the displayed mine field.
											//It is changed by the displayfield f(x) so that the AI cannot
											//cheat.
	int numbombs, x, y;
	bool gameover;
	char again;
	Aims rover(WIDTH, HEIGHT);

	do{
	cout << "ten mines.\n";
	numbombs = 10;

	//place the bombs!
	SetupMineField(minefield, numbombs);
	displayedfield = AI_field(WIDTH, HEIGHT);
	DisplayField(minefield, displayedfield);
	gameover = false;
	while (!gameover)
	{
		rover.examine_field(displayedfield);
		//for(int i = 0; i < HEIGHT; i++){
		//	for(int j = 0; j < WIDTH; j++){
		//		rover.adja(displayedfield, i, j);
		//	}
		//}

		//ask user to choose coords
		/*cout << "Choose location: x y ";
		cin >> x >> y;
		if (cin.fail())
			break;*/
		if(rover.how_many() > 0){
		while(rover.how_many() != 0){
			rover.Aim_act(x, y);
			gameover = Reveal(minefield, x, y);
		}
		}
		else{
			rover.Aim_act(x, y);
			gameover = Reveal(minefield, x, y);
		}

		//reveal and maybe die?
		gameover = Reveal(minefield, x, y);
		//show the field
		DisplayField(minefield, displayedfield);
	}

	cout << "Game Over!! Would you like to play again? (y/n):";
	cin >> again;
	}while(tolower(again) == 'y');

	cout << "Good bye.\n";
	return 0;
}

int **AI_field(int width, int height){
	int **ai_field;

	ai_field = new int* [height];
	for(int i = 0; i < height; i++){
		ai_field[i] = new int [width];
	}
	return ai_field;
}