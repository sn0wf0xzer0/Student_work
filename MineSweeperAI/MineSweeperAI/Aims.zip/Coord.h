//This struct is used to keep track of coordinants on a two dimensional cartesian plane or any other pair of int values.
//Author: John Palacios.

struct Coord
{
	int x;
	int y;
};