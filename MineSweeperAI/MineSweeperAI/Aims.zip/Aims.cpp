//Implementation file for AIMS class.
//Author: John Palacios.

#include "Aims.h"
#include <iostream>
using namespace std;

Aims::Aims()
{
	gause_field = new int* [10];
	for(int i = 0; i < 10; i++){
		gause_field[i] = new int [10];
	}
	num_moves = 0;
	field_hight = 10;
	field_width = 10;
	mine_field = new char* [10];
	for(int i = 0; i < 10; i++){
		mine_field[i] = new char [10];
		for(int j = 0; j < 10; j++)
			mine_field[i][j] = ' ';
	}
	mode = 0;
}

Aims::Aims(int height, int width){
	gause_field = new int* [height];
	for(int i = 0; i < 10; i++){
		gause_field[i] = new int [width];
	}
	num_moves = 0;
	field_hight = height;
	field_width = width;
	mine_field = new char* [height];
	for(int i = 0; i < 10; i++){
		mine_field[i] = new char [width];
		for(int j = 0; j < 10; j++)
			mine_field[i][j] = ' ';
	}
	mode = 0;
}

void Aims::adja(int **field, int x, int y)
{
	int val_atXY = gause_field[x][y];
	int num_adja = 0;
	int count	 = 0;

	//count the number of known mines and undiscovere squares around space x, y.
	num_knowMine = 0;
	num_unreveal = 0;

	for(int i = x-1; i < x+2; i++){
		for(int j = y-1; j < y+2; j++){
			if((i > -1 && 10 > i && y > -1 && 10 > y) && (!(i == 0) && (j == 0))){
				num_adja++;
			}
		}
	}

	adj_spaces = new Coord [num_adja];

	for(int i = x-1; i < x+2; i++){
		for(int j = y-1; j < y+2; j++){
			if((i > -1 && 10 > i && y > -1 && 10 > y) && (!(i == 0) && (j == 0))){
				adj_spaces[count].x = j;
				adj_spaces[count].y = i;
				if(mine_field[i][j] == 'x')
					num_knowMine++;
				if(field[i][j] == -1)
					num_unreveal++;
			}
		}
	}

	//add to spaces not to touch
	if(val_atXY == num_unreveal){
		for(int i = 0; i < num_adja; i++){
			mine_field[adj_spaces[i].x][adj_spaces[i].y] = 'x';
		}
	}

	//add adjacent spaces to choose next.
	if((num_knowMine < num_unreveal) && (num_unreveal > val_atXY)){
		for(int i = 0; i < num_adja; i++){
			if((mine_field[adj_spaces[i].x][adj_spaces[i].y] != 'x') && (field[adj_spaces[i].x][adj_spaces[i].y] == -1)){
				//next_move.x = adj_spaces[i].x;  *next loop will assign these values to elements of next_moves.
				//next_move.y = adj_spaces[i].y;
				//Determine the number of moves to take next.
				num_moves++;
			}
		}
		next_move = new Coord [num_moves];
		for(int i = 0; i < num_moves; i++){
			if((mine_field[adj_spaces[i].x][adj_spaces[i].y] != 'x') && (field[adj_spaces[i].x][adj_spaces[i].y] == -1)){
				next_move[count].x = adj_spaces[i].x;
				next_move[count].y = adj_spaces[i].y;
				count++;
			}
		}
	}

	delete [] adj_spaces;
}

void Aims::Aim_act(int &x, int &y)
{
	num_moves--;
	x = next_move[num_moves].x;
	y = next_move[num_moves].y;
}

void Aims::examine_field(int **field)
{
	for(int i = 0; i < field_hight; i++){
		for(int j = 0; j < field_width; j++){
			if(field[i][j] != -1){
				gause_field[i][j] = field[i][j];
				adja(gause_field, i, j);
			}
		}
	}
}

void Aims::hunt(int &x, int &y)
{
	int h;
	int w;
	for(int k = 0; k < 2; k++){
		for(int l = 0; l < 2; l++){
			for(int m = 0; m < 2; m++){
				for(int i = 0; i < 2; i++){
					for(int j = 0; j < 2; j++){
						h = 2 + -l^k +5*i;
						w = 2 + -l^k +5*j;
						if(gause_field[h][w] == -1){
							num_moves = 1;
							next_move = new Coord;
							next_move[0].x = h;
							next_move[0].y = w;
							mode++;
						}
					}
				}
			}
		}
	}
}