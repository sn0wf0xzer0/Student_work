//This is the AIMS class: Artificial Intelegence MineSweeper.
//Author: John Palacios

#include "Coord.h"
using namespace std;

#ifndef AIMS
#define AIMS



class Aims
{
private:
	//Do not choose array.
	//next move array.
	//view of field.
	//mode. int mode, hunt == 0, zero == 1, count == 2 maybe?
	int **gause_field;	//All revealed numbers are stored here.
	//bool move_resol;	//true if the AI has decided on it's next move. *If num_moves > 0; then the next move has been resolved.
	int field_hight;
	int field_width;
	Coord *next_move;	//The next moves that the AI will take.
	Coord *adj_spaces;	//all spaces adjacent to [x][y].
	int num_adjacent;	//The number of Coords in adj_spaces.
	int num_moves;		//number of moves planned out.
	char **mine_field;	//Do not choose entries in this field
	int num_unreveal;	//Number of adjacent spaces to [x][y] which have not been revealed.
	int num_knowMine;	//Number of known mines in spaces adjacent to [x][y].
	int mode;			//0 is initial hunting, 1 is scanning, 2 is guessing.
	//collects list of adjacent spaces.
	void adja(int **, int, int);
	//oppener strategy.
	void hunt(int &, int &);
	//clears all zero's
	void zero(int &, int &);
	//determines safe spaces and danger spaces.
	//void count(int, int);		//Taken care of in f(x) adja.
	//pattern matching can help determine likely scenarios.
	void match(int &, int &);
	//Specific pattern with pi/2 rotational symetry.
	void one_1(int &, int &);
	//Specific pattern with pi/2 rotational symetry.
	void one_2(int &, int &);
public:
	//Initializes do not choose array and next move array to a 10 by 10.
	//mode = 0;
	Aims();
	//Initializes do not choose array and next move array with height by width
	//and mode = 0;
	Aims(int, int);
	~Aims();
	//Syncronizes AI understanding of game field.
	void examine_field(int **);
	//returns AI mode.
	int get_mode()
	{ return mode;}
	//Returns the number of moves the AI has planned out.
	int how_many()
	{ return num_moves; }
	//Main function for AI turn taking.
	void Aim_act(int &, int &);
};

#endif /* AIMS */