//This struct represents a point reference given three coordinants: x, y, and z.
//Author: John Palacios

#ifndef COORD_H
#define COORD_H

struct Coord
{
	double coords[3];
};

#endif /*COORD_H*/